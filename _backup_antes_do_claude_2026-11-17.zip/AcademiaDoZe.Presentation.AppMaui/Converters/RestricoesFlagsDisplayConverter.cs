using AcademiaDoZe.Application.Enums;
using AcademiaDoZe.Presentation.AppMaui.Helpers;
using System.Globalization;

namespace AcademiaDoZe.Presentation.AppMaui.Converters;

// Converte o enum [Flags] AppMatriculaRestricoes para uma string amigável (lista separada por vírgula)
// Utiliza o atributo [Display(Name = "...")] para obter nomes amigáveis
public sealed class RestricoesFlagsDisplayConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is not AppMatriculaRestricoes flags) return string.Empty;

        // Nenhuma
        if (flags == AppMatriculaRestricoes.None) return Nome(AppMatriculaRestricoes.None);

        // Junta todos os que estão marcados
        var partes = new List<string>();
        foreach (var v in Enum.GetValues<AppMatriculaRestricoes>().Cast<AppMatriculaRestricoes>())
        {
            if (v == AppMatriculaRestricoes.None) continue;
            if (flags.HasFlag(v)) partes.Add(Nome(v));
        }
        return partes.Count > 0 ? string.Join(", ", partes) : Nome(AppMatriculaRestricoes.None);
    }

    private static string Nome(AppMatriculaRestricoes v) => L.NomeEnum(v, v.GetDisplayName());

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
