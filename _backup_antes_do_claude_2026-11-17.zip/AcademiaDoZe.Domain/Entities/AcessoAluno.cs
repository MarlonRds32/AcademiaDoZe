﻿using System;
using System.Collections.Generic;
using System.Text;
using AcademiaDoZe.Domain.Common;
using AcademiaDoZe.Domain.Services;
// Marlon Rodrigues
namespace AcademiaDoZe.Domain.Entities
{
    public class AcessoAluno : Entity, IAggregateRoot
    {
        public Aluno Aluno { get; private set; }
        public DateTime DataHora { get; private set; }
        private AcessoAluno(int id, Aluno aluno, DateTime dataHora) : base(id)
        {
            Aluno = aluno;
            DataHora = dataHora;
        }
        public static Result<AcessoAluno> Criar(int id, Aluno aluno, DateTime dataHora)
        {
            var notifications = new List<Notification>();

            if (aluno == null)
                notifications.Add(new Notification("Aluno", "ALUNO_INVALIDO"));

            if (dataHora == default)
                notifications.Add(new Notification("DataHora", "DATA_HORA_OBRIGATORIA"));
            else if (dataHora.TimeOfDay < new TimeSpan(6, 0, 0) || dataHora.TimeOfDay > new TimeSpan(22, 0, 0)) 
                notifications.Add(new Notification("DataHora", "DATA_HORA_INTERVALO_INVALIDO"));


            if (notifications.Count != 0)
                return Result<AcessoAluno>.Failure(notifications);

            return Result<AcessoAluno>.Success(new AcessoAluno(id, aluno!, dataHora));
        }
    }
}
