﻿using System;
using System.Collections.Generic;
using System.Text;
using AcademiaDoZe.Domain.Common;
using AcademiaDoZe.Domain.Services;
// Marlon Rodrigues
namespace AcademiaDoZe.Domain.Entities
{
    public class AcessoColaborador : Entity, IAggregateRoot
    {
        public Colaborador Colaborador { get; private set; }
        public DateTime DataHora { get; private set; }
        private AcessoColaborador(int id, Colaborador colaborador, DateTime dataHora) : base(id)
        {
            Colaborador = colaborador;
            DataHora = dataHora;
        }
        public static Result<AcessoColaborador> Criar(int id, Colaborador colaborador, DateTime dataHora)
        {
            var notifications = new List<Notification>();

            if (colaborador == null)
                notifications.Add(new Notification("Colaborador", "COLABORADOR_INVALIDO"));

            if (dataHora == default)
                notifications.Add(new Notification("DataHora", "DATA_HORA_OBRIGATORIA"));
            else if (dataHora.TimeOfDay < new TimeSpan(6, 0, 0) || dataHora.TimeOfDay > new TimeSpan(22, 0, 0))
                notifications.Add(new Notification("DataHora", "DATA_HORA_INTERVALO_INVALIDO"));


            if (notifications.Count != 0)
                return Result<AcessoColaborador>.Failure(notifications);

            return Result<AcessoColaborador>.Success(new AcessoColaborador(id, colaborador!, dataHora));
        }
    }
}
