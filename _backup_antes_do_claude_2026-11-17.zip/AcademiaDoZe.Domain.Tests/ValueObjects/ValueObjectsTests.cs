﻿using AcademiaDoZe.Domain.Entities;
using AcademiaDoZe.Domain.ValueObjects;
namespace AcademiaDoZe.Domain.Tests.ValueObjects;
// Marlon Rodrigues
public class ValueObjectsTests
{
    [Theory(DisplayName = "Cep: dígitos inválidos -> CEP_DIGITOS")]
    [InlineData
    ("123")]
    [InlineData
    ("12-345")]
    public void Deve_Falhar_Criacao_Quando_CepDigitosInvalidos
    (string input)

    {
        var result = Cep
        .Criar
        (input);

        Assert
        .True
        (result.IsFailure);

        Assert
        .NotEmpty
        (result.Notifications);

    }
    [Theory(DisplayName = "Cep: formatos válidos (com e sem hífen)")]
    [InlineData
    ("12345-678")]
    [InlineData
    ("12345678")]
    public void Deve_Criar_Cep_Quando_Valido
    (string input)

    {
        var result = Cep
        .Criar
        (input);

        Assert
        .True
        (result.IsSuccess);

        Assert
        .Equal
        ("12345678", result.Value!.Valor);

    }
    [Theory(DisplayName = "Cep: obrigatório -> CEP_OBRIGATORIO")]
    [InlineData
    (null)]
    [InlineData
    ("")]
    public void Deve_Falhar_Criacao_Quando_CepNuloOuVazio
    (string? input)

    {
        var result = Cep
        .Criar
        (input!);

        Assert
        .True
        (result.IsFailure);

        Assert
        .Contains
        (result.Notifications,
        n =>
        n.Mensagem == "CEP_OBRIGATORIO");

    }
    [Theory(DisplayName = "Endereco: criação válida com número e complemento")]
    [InlineData
    ("10", "Bloco A")]
    [InlineData
    ("1", "")]
    public void Deve_Criar_Endereco_Quando_Valido

    (string numero, string complemento)

    {
        var logradouro = Logradouro

        .Criar(1, "12345-678", "Rua Teste", "Bairro", "Cidade", "SP", "Brasil").Value!;

        var result = Endereco
        .Criar
        (logradouro, numero, complemento);

        Assert
        .True
        (result.IsSuccess);

        Assert
        .Equal
        (logradouro.Id, result.Value!.Logradouro.Id);

        Assert
        .Equal
        (numero, result.Value.Numero);

        Assert
        .Equal
        (complemento, result.Value.Complemento);

    }
    [Theory(DisplayName = "Endereco: valida obrigatoriedade do logradouro e número")]
    [InlineData
    ("invalid", "1", "LOGRADOURO_OBRIGATORIO")]
    [InlineData
    ("valid", "", "NUMERO_OBRIGATORIO")]
    public void Deve_Falhar_Criacao_Quando_EnderecoInvalido

    (string logradouroCase, string numero, string expected)

    {
        Logradouro? logradouro = null;
        if (logradouroCase == "valid")
            logradouro = Logradouro

            .Criar(1, "12345-678", "Rua Teste", "Bairro", "Cidade", "SP", "Brasil").Value!;

        var result = Endereco
        .Criar
        (logradouro!, numero, "");

        Assert
        .True
        (result.IsFailure);

        Assert
        .Contains
        (result.Notifications,
        n =>
        n.Mensagem == expected);

    }

    [Theory(DisplayName = "Cpf: nulo/vazio/espaços -> CPF_OBRIGATORIO")]
    [InlineData(null)]
    [InlineData("")]
    [InlineData(" ")]
    public void Deve_Falhar_Criacao_Quando_CpfNuloOuVazio(string? input)
    {
        var result = Cpf.Criar(input!);
        Assert.True(result.IsFailure);
        Assert.Single(result.Notifications);
        Assert.Equal("CPF_OBRIGATORIO", result.Notifications.First().Mensagem);
    }
    [Theory(DisplayName = "Cpf: formatos válidos (com e sem pontuação)")]
    [InlineData("529.982.247-25")]
    [InlineData("52998224725")]
    public void Deve_Criar_Cpf_Quando_ValorValido(string input)
    {
        var result = Cpf.Criar(input);
        Assert.True(result.IsSuccess);
        Assert.Equal("52998224725", result.Value!.Valor);
    }
    [Theory(DisplayName = "Cpf: inválido - dígitos/verificador incorreto -> CPF_INVALIDO")]
    [InlineData("123.456.789-00")]
    [InlineData("111.111.111-11")]
    public void Deve_Falhar_Criacao_Quando_CpfInvalido(string input)
    {
        var result = Cpf.Criar(input);
        Assert.True(result.IsFailure);
        Assert.NotEmpty(result.Notifications);
    }
    [Theory(DisplayName = "Cpf: sem dígitos -> CPF_DIGITOS")]
    [InlineData(" dfgdf ")]
    [InlineData("abc")]
    public void Deve_Falhar_Criacao_Quando_CpfSemDigitos(string input)
    {
        var result = Cpf.Criar(input);
        Assert.True(result.IsFailure);
        Assert.NotEmpty(result.Notifications);
        Assert.Contains(result.Notifications, n => n.Mensagem == "CPF_DIGITOS");
    }

    [Theory(DisplayName = "Telefone: dígitos inválidos -> TELEFONE_DIGITOS")]
    [InlineData("1234")]
    [InlineData("(1)2345")]
    public void Deve_Falhar_Criacao_Quando_TelefoneDigitosInvalidos(string input)
    {
        var result = Telefone.Criar(input);
        Assert.True(result.IsFailure);
        Assert.NotEmpty(result.Notifications);
    }
    [Theory(DisplayName = "Telefone: formatos válidos (com e sem formatação)")]
    [InlineData("(11) 91234-5678")]
    [InlineData("11912345678")]
    public void Deve_Criar_Telefone_Quando_Valido(string input)
    {
        var result = Telefone.Criar(input);
        Assert.True(result.IsSuccess);
        Assert.Equal("11912345678", result.Value!.Valor);
    }
    [Theory(DisplayName = "Telefone: obrigatório -> TELEFONE_OBRIGATORIO")]
    [InlineData(null)]
    [InlineData("")]
    public void Deve_Falhar_Criacao_Quando_TelefoneNuloOuVazio(string? input)
    {
        var result = Telefone.Criar(input!);
        Assert.True(result.IsFailure);
        Assert.Contains(result.Notifications, n => n.Mensagem == "TELEFONE_OBRIGATORIO");
    }
    [Theory(DisplayName = "Senha: valida requisito de uppercase")]
    [InlineData("abcdef", false)]
    [InlineData("Abcdef", true)]
    public void Deve_Validar_RequisitoUppercase_Senha(string senha, bool isSuccess)
    {
        var result = Senha.Criar(senha);
        Assert.Equal(isSuccess, result.IsSuccess);
    }
    [Theory(DisplayName = "Senha: obrigatório -> SENHA_OBRIGATORIO")]
    [InlineData(null)]
    [InlineData("")]
    public void Deve_Falhar_Criacao_Quando_SenhaNulaOuVazia(string? input)
    {
        var result = Senha.Criar(input!);
        Assert.True(result.IsFailure);
        Assert.Contains(result.Notifications, n => n.Mensagem == "SENHA_OBRIGATORIO");
    }

    [Theory(DisplayName = "Cep: contém letras -> CEP_DIGITOS")]
    [InlineData("abcde-123")]
    [InlineData("12345-abc")]
    public void Deve_Falhar_Criacao_Quando_CepContemLetras(string input)
    {
        // Arrange + Act: chama Cep.Criar com um CEP que tem letras misturadas
        var result = Cep.Criar(input);

        // Assert: espera falha, pois depois de limpar os dígitos, sobra menos de 8 números
        Assert.True(result.IsFailure);
        Assert.Contains(result.Notifications, n => n.Mensagem == "CEP_DIGITOS");
    }


    [Fact(DisplayName = "Endereco: complemento vazio é aceito (opcional)")]
    public void Deve_Criar_Endereco_Quando_ComplementoVazio()
    {
        // Arrange
        var logradouro = Logradouro.Criar(1, "12345-678", "Rua Teste", "Bairro", "Cidade", "SP", "Brasil").Value!;

        // Act
        var result = Endereco.Criar(logradouro, "100", "");

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal("", result.Value!.Complemento);
    }

    [Theory(DisplayName = "Telefone: fixo (10 dígitos) -> TELEFONE_DIGITOS")]
    [InlineData("(11) 3456-7890")]
    [InlineData("1134567890")]
    public void Deve_Falhar_Criacao_Quando_TelefoneFixoComDezDigitos(string input)
    {
        // Arrange + Act
        var result = Telefone.Criar(input);

        // Assert: seu Telefone.Criar exige exatamente 11 dígitos, então fixo (10) falha
        Assert.True(result.IsFailure);
        Assert.Contains(result.Notifications, n => n.Mensagem == "TELEFONE_DIGITOS");
    }
    [Theory(DisplayName = "Email: formatos inválidos diversos -> EMAIL_FORMATO")]
    [InlineData("semarroba.com")]
    [InlineData("usuario@")]
    [InlineData("usuario@dominio")]
    [InlineData("@dominio.com")]
    public void Deve_Falhar_Criacao_Quando_EmailFormatoInvalido(string input)
    {
        var result = Email.Criar(input);

        Assert.True(result.IsFailure);
        Assert.Contains(result.Notifications, n => n.Mensagem == "EMAIL_FORMATO");
    }

    [Fact(DisplayName = "Email: formato válido com subdominio")]
    public void Deve_Criar_Email_Quando_ValidoComSubdominio()
    {
        var result = Email.Criar("usuario@mail.example.com");

        Assert.True(result.IsSuccess);
        Assert.Equal("usuario@mail.example.com", result.Value!.Valor);
    }

    [Fact(DisplayName = "Arquivo: nulo -> ARQUIVO_OBRIGATORIO")]
    public void Deve_Falhar_Criacao_Quando_ArquivoNulo()
    {
        var result = Arquivo.Criar(null!);

        Assert.True(result.IsFailure);
        Assert.Contains(result.Notifications, n => n.Mensagem == "ARQUIVO_OBRIGATORIO");
    }

    [Fact(DisplayName = "Arquivo: array vazio é aceito (0 bytes não excede limite)")]
    public void Deve_Criar_Arquivo_Quando_ArrayVazio()
    {
        var result = Arquivo.Criar(Array.Empty<byte>());

        Assert.True(result.IsSuccess);
    }





}